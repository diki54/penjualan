﻿'difolder Module buatlah New Module 
'dengan nama
'ModObjekdanFungsi

Module ModObjekdanFungsi
    Public EntitasBarang As New ClsEntBarang
    Public KontrolBarang As New ClsCtlBarang
End Module
