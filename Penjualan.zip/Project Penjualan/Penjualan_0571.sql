create table Penjualan_0571(
kdbarang char(5) not null primary key,
namaBarang varchar(50) not null,
hargaBarang numeric(18,0) not null,
stokBarang int
)
INSERT INTO Penjualan_0571 VALUES
('A0001','LOMBOK',3000,34),
('A0002','BAWANG MERAH',500,10),
('A0003','BAWANG PUTIH',8500,20),
('A0004','JAHE',1500,40),
('A0005','KUNYIT',2000,55)

SELECT * FROM Penjualan_0571